// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
//	Modified by: Miguel A Rodao
//

#include <iomanip>
#include <iostream>

int main(){

	std::cout << "Buffer Overflow Example" << std::endl;

	// While true, ask for correct input
	while (true) {

		// Variables
		char user_input[20];
		const std::string account_number = "CharlieBrown42";

		try {
			
			std::cout << "Enter a value: ";
			std::cin >> user_input;

			if (strlen(user_input) > 20) {
				throw std::exception("Too many characters, try again.");
				std::cin.clear();
				std::cin.ignore(strlen(user_input), '\n');
			}
			else {
				std::cout << "You entered: " << user_input << std::endl;
				std::cout << "Account Number = " << account_number << std::endl;
				user_input[0] = '\0';
				break;
			}
		}	// TRY END
		catch (const std::exception& e) {
			std::cerr << "Caught exception: " << e.what() << std::endl;
		}	// CATCH END
	}	// WHILE END

	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
